<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;



class AdminLogin extends Controller
{
    //
        public function login(){

            return view('admin/login');

        }
}
