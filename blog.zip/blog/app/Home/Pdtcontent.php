<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Pdtcontent extends Model
{
    //
    protected $table='pdt_content';
}
