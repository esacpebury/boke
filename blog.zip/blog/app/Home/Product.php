<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $table='product';
}
