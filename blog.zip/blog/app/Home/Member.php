<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Member extends Model

{
    //
    protected $table='member';
}
