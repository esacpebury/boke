<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Pdtimage extends Model
{
    //
    protected $table='pdt_image';
}
